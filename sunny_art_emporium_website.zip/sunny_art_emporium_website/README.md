# Sunny Art Emporium — Website

A responsive, traditional Indian-inspired storefront built with plain HTML, CSS and JavaScript.

## Files
- `index.html` — site structure and sections
- `style.css` — responsive styling, colours, layout and mobile navigation
- `script.js` — sample product catalogue, search/filter, shopping bag, enquiry form, WhatsApp order preparation

## Run it
1. Keep all three files in the same folder.
2. Open `index.html` in a browser. For the best local testing experience, use a simple local web server or an editor such as VS Code with Live Server.
3. Internet is required for the Google Fonts and externally hosted sample photos.

## Before publishing
1. **Set your WhatsApp number:** open `script.js` and replace `91XXXXXXXXXX` in `WHATSAPP_NUMBER` with your real business number including country code, digits only. Example format: `919876543210`.
2. **Replace sample product content:** edit the `products` array in `script.js` with your real product names, descriptions, prices, and image URLs.
3. **Use your real product photographs:** upload images to your website host and use their URLs, or put local images in an `images` folder and update the paths.
4. **Confirm prices:** displayed starting prices are sample placeholders. Update them before publishing.
5. **Add business details:** add your actual phone, email, shipping policy, returns policy, privacy policy, and business address as appropriate.
6. **Publish:** upload these files to your hosting provider or deploy them with a static website host.

## Important limitations
- The cart and order builder run in the browser; this starter does not include a database, stock management, payment gateway, customer accounts, or a server-side order system.
- The “checkout” action sends the order summary to WhatsApp once you configure the number. It is not an online payment checkout.
- The enquiry form does not save submissions to a server. With the default unconfigured number, it downloads the prepared enquiry text.
- Product prices, product imagery and catalogue descriptions are examples and must be verified/replaced by the business.
