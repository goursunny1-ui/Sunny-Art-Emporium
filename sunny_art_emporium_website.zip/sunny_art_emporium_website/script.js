/*
  Sunny Art Emporium website
  IMPORTANT: Set WHATSAPP_NUMBER below to the business WhatsApp number,
  including country code and digits only (example: 919876543210).
  Product names, images and starting prices below are editable sample content.
*/
const WHATSAPP_NUMBER = "91XXXXXXXXXX"; // Replace with your real WhatsApp number.

const products = [
  {id:1,name:"Radha Krishna Murti",category:"Gods & Goddesses",tag:"Bestseller",price:8500,priceText:"From ₹8,500",description:"A graceful devotional pair for your home mandir.",image:"https://images.unsplash.com/photo-1606293926075-69a00db67a4a?auto=format&fit=crop&w=700&q=80"},
  {id:2,name:"Ganesh Ji Murti",category:"Gods & Goddesses",tag:"Handcrafted",price:6500,priceText:"From ₹6,500",description:"An auspicious centrepiece with traditional detailing.",image:"https://images.unsplash.com/photo-1567591414240-e9c1e8f5a5b0?auto=format&fit=crop&w=700&q=80"},
  {id:3,name:"Parshvanath Ji Murti",category:"Jain Murtis",tag:"Made to order",price:9500,priceText:"From ₹9,500",description:"A serene Jain murti with a timeless finish.",image:"https://images.unsplash.com/photo-1604608672516-7d0d7f0a9b91?auto=format&fit=crop&w=700&q=80"},
  {id:4,name:"Temple Decorative Art",category:"Temple Art",tag:"Artisan pick",price:4200,priceText:"From ₹4,200",description:"Traditional accents to complement your sacred space.",image:"https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?auto=format&fit=crop&w=700&q=80"},
  {id:5,name:"Shiv Ji Murti",category:"Gods & Goddesses",tag:"Custom sizes",price:7800,priceText:"From ₹7,800",description:"A devotional sculpture inspired by Indian tradition.",image:"https://images.unsplash.com/photo-1606293926075-69a00db67a4a?auto=format&fit=crop&w=700&q=80"},
  {id:6,name:"Mahavir Swami Murti",category:"Jain Murtis",tag:"Made to order",price:9000,priceText:"From ₹9,000",description:"Peaceful form for a home, temple, or meditation space.",image:"https://images.unsplash.com/photo-1604608672516-7d0d7f0a9b91?auto=format&fit=crop&w=700&q=80"},
  {id:7,name:"Mandir Accent Piece",category:"Temple Art",tag:"Traditional",price:3200,priceText:"From ₹3,200",description:"A thoughtful finishing touch for your prayer room.",image:"https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?auto=format&fit=crop&w=700&q=80"},
  {id:8,name:"Custom Marble Murti",category:"Gods & Goddesses",tag:"Personalised",price:12000,priceText:"Request a quote",description:"Share your deity, preferred size, and design details.",image:"https://images.unsplash.com/photo-1567591414240-e9c1e8f5a5b0?auto=format&fit=crop&w=700&q=80"}
];

let activeCategory = "All";
let cart = [];
const $ = (selector) => document.querySelector(selector);
const productGrid = $("#productGrid");
const cartDrawer = $("#cartDrawer");
const overlay = $("#cartOverlay");
const toast = $("#toast");
let toastTimer;

function formatPrice(amount) {
  return new Intl.NumberFormat("en-IN", {style:"currency", currency:"INR", maximumFractionDigits:0}).format(amount);
}
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function renderProducts() {
  const term = $("#productSearch").value.trim().toLowerCase();
  const filtered = products.filter(p =>
    (activeCategory === "All" || p.category === activeCategory) &&
    `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(term)
  );
  if (!filtered.length) {
    productGrid.innerHTML = '<p class="no-results">No pieces found. Try another search or category.</p>';
    return;
  }
  productGrid.innerHTML = filtered.map(p => `
    <article class="product-card">
      <div class="product-image">
        <img src="${p.image}" alt="${escapeHtml(p.name)}" loading="lazy" onerror="this.style.display='none';this.parentElement.classList.add('image-fallback')">
        <span class="product-tag">${escapeHtml(p.tag)}</span>
        <button class="quick-add" data-add="${p.id}">＋ Add to bag</button>
      </div>
      <div class="product-info">
        <p class="product-category">${escapeHtml(p.category)}</p>
        <h3>${escapeHtml(p.name)}</h3>
        <p class="description">${escapeHtml(p.description)}</p>
        <div class="product-bottom"><div><div class="price">${escapeHtml(p.priceText)}</div><div class="price-note">Price varies by size & finish</div></div><button class="detail-button" data-enquire="${p.id}">Enquire ↗</button></div>
      </div>
    </article>`).join("");
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function addToCart(id) {
  const product = products.find(p => p.id === Number(id));
  if (!product) return;
  const existing = cart.find(item => item.id === product.id);
  if (existing) existing.qty += 1;
  else cart.push({...product, qty:1});
  renderCart();
  showToast(`${product.name} added to your bag`);
}
function changeQty(id, amount) {
  const item = cart.find(p => p.id === Number(id));
  if (!item) return;
  item.qty += amount;
  if (item.qty <= 0) cart = cart.filter(p => p.id !== Number(id));
  renderCart();
}
function renderCart() {
  const count = cart.reduce((sum, item) => sum + item.qty, 0);
  $("#cartCount").textContent = count;
  $("#cartItems").innerHTML = cart.length ? cart.map(item => `
    <div class="cart-line">
      <img src="${item.image}" alt="" onerror="this.style.display='none'">
      <div><h4>${escapeHtml(item.name)}</h4><small>${escapeHtml(item.priceText)}</small>
        <div class="quantity-controls"><button data-qty="${item.id}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${item.qty}</span><button data-qty="${item.id}" data-delta="1" aria-label="Increase quantity">+</button></div>
        <button class="remove-item" data-remove="${item.id}">Remove</button>
      </div><strong>${formatPrice(item.price * item.qty)}</strong>
    </div>`).join("") : '<div class="empty-cart">Your bag is waiting for something special. ✧<br><br>Add a piece from our collection to get started.</div>';
  $("#cartTotal").textContent = formatPrice(cart.reduce((sum,item)=>sum+item.price*item.qty,0));
}
function openCart() {
  cartDrawer.classList.add("open"); overlay.classList.add("open");
  cartDrawer.setAttribute("aria-hidden","false");
  document.body.style.overflow = "hidden";
}
function closeCart() {
  cartDrawer.classList.remove("open"); overlay.classList.remove("open");
  cartDrawer.setAttribute("aria-hidden","true");
  document.body.style.overflow = "";
}
function orderText() {
  if (!cart.length) return "Hello Sunny Art Emporium, I would like to enquire about your products.";
  const lines = cart.map(item => `• ${item.name} × ${item.qty} — estimated ${formatPrice(item.price * item.qty)}`);
  const total = cart.reduce((sum,item)=>sum+item.price*item.qty,0);
  return `Namaste Sunny Art Emporium! I would like to enquire about this order:\n\n${lines.join("\n")}\n\nEstimated subtotal: ${formatPrice(total)}\nPlease confirm final price, size options, availability and shipping.`;
}
function whatsappReady() {
  return /^\d{10,15}$/.test(WHATSAPP_NUMBER) && !WHATSAPP_NUMBER.includes("X");
}
function continueWhatsApp(message) {
  if (!whatsappReady()) {
    $("#cartStatus").textContent = "To activate WhatsApp orders, open script.js and replace WHATSAPP_NUMBER with your business number (country code + digits). You can copy the order details meanwhile.";
    showToast("Add your WhatsApp number in script.js first");
    return;
  }
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
}
productGrid.addEventListener("click", e => {
  const add = e.target.closest("[data-add]");
  const enquire = e.target.closest("[data-enquire]");
  if (add) addToCart(add.dataset.add);
  if (enquire) {
    const p = products.find(item => item.id === Number(enquire.dataset.enquire));
    $("#interest").value = p?.name || "Marble Murti";
    $("#contact").scrollIntoView({behavior:"smooth"});
    $("#enquiryForm").elements.message.value = `I would like details about ${p.name}. Please share available sizes, final pricing, and delivery options.`;
  }
});
$("#filterTabs").addEventListener("click", e => {
  const button = e.target.closest("[data-category]");
  if (!button) return;
  activeCategory = button.dataset.category;
  document.querySelectorAll(".filter").forEach(b => b.classList.toggle("active", b === button));
  renderProducts();
});
$("#productSearch").addEventListener("input", renderProducts);
$("#openCart").addEventListener("click", openCart);
$("#closeCart").addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);
document.addEventListener("keydown", e => { if (e.key === "Escape") closeCart(); });
$("#cartItems").addEventListener("click", e => {
  const qty = e.target.closest("[data-qty]");
  const remove = e.target.closest("[data-remove]");
  if (qty) changeQty(qty.dataset.qty, Number(qty.dataset.delta));
  if (remove) { cart = cart.filter(p => p.id !== Number(remove.dataset.remove)); renderCart(); }
});
$("#checkoutButton").addEventListener("click", () => {
  if (!cart.length) { showToast("Your bag is empty"); return; }
  continueWhatsApp(orderText());
});
$("#copyCart").addEventListener("click", async () => {
  const text = orderText();
  try {
    await navigator.clipboard.writeText(text);
    $("#cartStatus").textContent = "Order details copied. You can paste them into WhatsApp or another message.";
  } catch {
    const area = document.createElement("textarea");
    area.value = text; document.body.appendChild(area); area.select();
    const ok = document.execCommand("copy"); area.remove();
    $("#cartStatus").textContent = ok ? "Order details copied." : text;
  }
});
$("#enquiryForm").addEventListener("submit", e => {
  e.preventDefault();
  const form = e.currentTarget;
  const data = new FormData(form);
  const name = String(data.get("name") || "").trim();
  const phone = String(data.get("phone") || "").trim();
  const interest = String(data.get("interest") || "");
  const message = String(data.get("message") || "").trim();
  const fullMessage = `Namaste Sunny Art Emporium!\n\nOrder enquiry from: ${name}\nPhone: ${phone || "Not provided"}\nInterested in: ${interest}\nRequirements: ${message}\n\nPlease share details, final pricing, and shipping options.`;
  $("#formStatus").textContent = "Your enquiry is ready. Continue to WhatsApp, or copy it from the prompt if WhatsApp is not configured.";
  if (whatsappReady()) {
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(fullMessage)}`, "_blank", "noopener,noreferrer");
  } else {
    const blob = new Blob([fullMessage], {type:"text/plain"});
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = "sunny-art-emporium-enquiry.txt";
    link.click(); URL.revokeObjectURL(url);
    $("#formStatus").textContent = "Enquiry text downloaded. Configure your WhatsApp number in script.js to open WhatsApp directly.";
  }
});
$("#menuToggle").addEventListener("click", () => {
  const nav = $("#mainNav");
  const opened = nav.classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded", String(opened));
});
$("#mainNav").addEventListener("click", e => {
  if (e.target.closest("a")) { $("#mainNav").classList.remove("open"); $("#menuToggle").setAttribute("aria-expanded","false"); }
});
$("#year").textContent = new Date().getFullYear();
renderProducts();
renderCart();
